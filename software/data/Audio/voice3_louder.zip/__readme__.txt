For 6 dB (double the voltage) louder audio (but distorted due to clipping) in traffic warnings in SkyView, copy these WAV files over the original ones in the Audio/voice3 folder on the SD card.
